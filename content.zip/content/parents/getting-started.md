# Getting Started with AYSO Region 13

Welcome to AYSO Region 13. We're a volunteer-run youth soccer organization serving Pasadena, La Cañada, Altadena, and surrounding communities.

[IMAGE: Kids of various ages playing soccer - diverse group]

## Quick Facts

- Season: September through mid-November (after Labor Day)
- Ages: 4 years old through high school (19U)
- Cost: $210-$240 depending on registration date (scholarships available)
- Location: Various fields across Pasadena and La Cañada — [see our field map](/fields)

---

## How Registration Works

Registration typically opens May 1 each year. Earlier registration costs less:

| Registration Period | Cost |
|---------------------|------|
| May 1 - May 31 | $210 |
| June 1 - July 15 | $220 |
| July 16 - August 15 | $230 |
| After August 15 | $240 |

Sibling discount: $20 off per additional child (through May 31)

Scholarships: No child is turned away for financial reasons. Contact [registrar@ayso13.org](mailto:registrar@ayso13.org) confidentially.

[INLEAGUE: Registration link - opens in new tab]

### What's Included in Registration

- Team jersey, shorts, and socks
- 8-10 weeks of games (Saturdays)
- Weekly team practices
- End-of-season participation award
- Insurance coverage during AYSO activities

You provide: Soccer shoes (sneakers are fine) and shin guards. See our [equipment guide](/parents/equipment) for recommendations.

---

## Age Groups and Divisions

Children are placed in divisions based on their age as of July 31 of the current year:

| Division | Ages | Format |
|----------|------|--------|
| 4U/5U (Preschool) | 4-5 | Small-sided games, learning basics |
| 6U | 6 | 4v4, no goalkeepers |
| 8U | 7-8 | 4v4, no goalkeepers |
| 10U | 9-10 | 7v7 with goalkeepers |
| 12U | 11-12 | 9v9 |
| 14U | 13-14 | 11v11 (full field) |
| 16U/19U | 15-19 | 11v11, [Upper Division program](/programs/upper-division) |

Check the [age chart](/register/age-divisions) for exact birth date cutoffs.

---

## The Volunteer Requirement

AYSO runs entirely on parent volunteers. When you register your child, you'll be asked to volunteer as either a:

- Coach — Lead practices and games (training provided, no experience needed)
- Referee — Officiate games (training provided, no experience needed)

No soccer experience is required. Our training classes cover everything you need to know.

Other volunteer opportunities include team manager, field host, and snack coordinator. Learn more at [Volunteer Roles](/volunteers/roles).

---

## How Teams Are Formed

### Younger Divisions (6U-8U)
Teams are organized by school or neighborhood when possible. This helps kids play with friends and makes carpooling easier.

### Older Divisions (10U and up)
Teams are formed through a blind draw process based on player skill ratings to create balanced teams.

You can request that your child be placed with a specific friend or carpool partner during registration. We accommodate requests when possible but cannot guarantee them.

---

## What to Expect

### Before the Season
1. Register (May-August)
2. Complete volunteer training (July-August) — [see training classes](/volunteers/classes)
3. Attend team meeting — Your coach will reach out with details
4. Pick up uniforms — Dates announced via email

### During the Season
- Practices: One weeknight per week (day/time set by your coach)
- Games: Saturday mornings at one of our [local fields](/fields)
- Season length: 8-10 weeks

### Communication
Your team manager and coach will communicate via email and often a team app. Watch for:
- Practice schedule and location
- Game times and field assignments
- Weather cancellations
- Team events

---

## Programs Beyond Fall Soccer

Fall soccer is our main program, but we offer others throughout the year:

| Program | When | Who It's For |
|---------|------|--------------|
| [Preschool](/programs/preschool) | Fall | Ages 4-5 |
| [NEXT](/programs/next) | Fall | Advanced players, 10U-14U |
| [Winter Stars](/programs/winter-stars) | Winter | All returning players |
| [Spring Soccer](/programs/spring-soccer) | Spring | Open registration |
| [Summer Camps](/programs/camps) | Summer | All ages |
| [EPIC](/programs/epic) | Fall | Children with special needs |

See all [programs](/programs) for details.

---

## Common Questions

**Do I need soccer experience to coach or referee?**
No. Our training classes teach you everything you need.

**What if my child has never played before?**
Most of our players are beginners. AYSO focuses on skill development, and every child plays at least half of every game.

**Can my child play with their friend?**
You can request placement with one friend during registration. We do our best to honor requests.

**What if we miss some games due to travel?**
Occasional absences are fine. Let your coach know in advance.

**Are scholarships available?**
Yes. No child is turned away. Contact [registrar@ayso13.org](mailto:registrar@ayso13.org) — all requests are confidential.

**What's the difference between AYSO and club soccer?**
AYSO is recreational and inclusive — everyone plays, teams are balanced. Club soccer is more competitive with tryouts and travel.

---

## Ready to Register?

[INLEAGUE: Large registration button/CTA]

Questions? Contact us at [registrar@ayso13.org](mailto:registrar@ayso13.org) or visit our [contact page](/contact).

---

## Related Pages

- [Equipment Guide](/parents/equipment) — What to buy and what's provided
- [Age Divisions](/register/age-divisions) — Exact birth date cutoffs
- [Field Map](/fields) — Where we play
- [Volunteer Training](/volunteers/classes) — Coach and referee certification
- [Parent Pledge](/parents/pledge) — Our commitment to positive sidelines

---

*Last updated: [DATE]*
