# Coaching

Coaching is one of the most rewarding ways to contribute to AYSO. No soccer experience is required — we provide all the training you need.

[IMAGE: Coach working with players]

---

## Why Coach?

- Make a difference in kids' lives
- Learn alongside your child
- Be part of a supportive community
- Training and resources provided

---

## Time Commitment

| Division | Practice | Games | Planning |
|----------|----------|-------|----------|
| 6U-8U | 60 min/week | Saturday mornings | ~30 min/week |
| 10U-14U | 90 min/week | Saturday mornings | ~60 min/week |

---

## Team Structure

### 6U-8U
Teams require both a Head Coach and Assistant Coach. During games, teams split in half and play on two fields simultaneously — one coach supervises each group.

### 10U-14U
Teams need a Head Coach. An Assistant Coach is recommended but not required.

---

## How to Become a Coach

1. Register as a volunteer through InLeague, selecting your coach preference and age division
2. Contact your Division Coach Administrator to confirm your interest
3. Complete required training (see [Training](/coaches/training))

[INLEAGUE: Volunteer registration link]

---

## What We Provide

Every coach receives:
- Coach bag with balls, pump, cones, pinnies
- First aid kit
- Laws of the Game booklet
- Duffel bag
- Age-specific coaching manual
- Training and certification

---

## Key Contacts

| Role | Contact |
|------|---------|
| Regional Coach Administrator | Brandi Lane |
| Deputy Coach Administrator | Susan Streets |

Division Coach Administrators oversee specific age groups and can answer division-specific questions.

---

## Coaching Resources

- [Getting Started](/coaches/getting-started) — First steps for new coaches
- [Training](/coaches/training) — Certification requirements
- [Practice Resources](/coaches/practice) — Planning practices
- [Game Day Guide](/coaches/game-day) — Running games
- [PIE Philosophy](/coaches/pie) — Positive coaching approach

---

## Related Pages

- [Volunteer Roles](/volunteers/roles) — Other ways to help
- [Training Classes](/volunteers/classes) — Schedule of classes
- [Coach FAQs](/coaches/faqs) — Common questions

---

*Last updated: [DATE]*
