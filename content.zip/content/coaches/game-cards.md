# Game Cards

Game cards are official match records used in 10U and older divisions to document participation, volunteer assignments, and game outcomes.

---

## What They Are

Game cards track:
- Teams and players
- Coaches and referees
- Scores
- Playing time
- Sportsmanship

---

## Coach Responsibilities

### Before the Game
Bring completed game cards to each match with the following pre-filled:
- Team name
- Coaches' names
- Full roster (players listed in jersey number order with first and last names)
- Game location
- Date and time
- Home or away designation

### During the Game
The referee team uses the card to track scoring, playing time, and sportsmanship.

### After the Game
Cards are submitted to the region.

---

## Format Options

Game cards are available in two formats:
- PDF (print and fill by hand)
- Google Sheets (editable, can print)

[INLEAGUE: Link to game card downloads]

---

## Tips

- Pre-print or handwrite completely and legibly
- List players in jersey number order
- Bring a backup copy in case of issues
- Keep a pen with your coaching supplies

---

## Related Pages

- [Game Day Guide](/coaches/game-day) — Running games
- [Practice Resources](/coaches/practice) — Planning practices

---

*Last updated: [DATE]*
