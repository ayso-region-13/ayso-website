# Referee Resources

Tools, documents, and guides for Region 13 referees.

---

## Quick Links

- [INLEAGUE: Referee Scheduler] — Sign up for games
- [INLEAGUE: eTrainU] — Training and certification
- [INLEAGUE: Incident Reporting] — Document issues

---

## Document Library

### Regional Guidelines (PDFs)
- Region 13 Guidelines for 6U/7U/8U Referees
- Region 13 Guidelines for 10U Referees
- Region 13 Guidelines for 12U Referees
- Region 13 Guidelines for Penalty Kicks

### National and International Resources (PDFs)
- IFAB Laws of the Game (current year)
- Changes to the Laws of the Game (current year)
- AYSO National Rules and Regulation Book
- AYSO Section 1 Rules and Regulations
- AYSO Addendum to the IFAB Laws of the Game
- Section 1 Player Development Initiative (PDI) Implementation
- Referee Quick Reference Card

### Training Materials
- Pre-Season Meeting Presentation (PDF and video)

[INLEAGUE: Link to full document library]

---

## Game Materials

**Log Pages**
Printable log pages for documenting match records.

**Game Cards**
Materials for recording game information. See [Game Cards](/coaches/game-cards) for usage instructions.

---

## Newsletters

Stay informed with these publications:
- AYSO Region 13 Referee Newsletter
- AYSO WhistleStop Newsletter

[INLEAGUE: Newsletter subscription links]

---

## Uniform and Equipment

Referee uniforms are available through the region. For uniform issues, contact [ref-uniforms@ayso13.org](mailto:ref-uniforms@ayso13.org) (Manny Morales).

---

## Contact

- Referee questions: [referee@ayso13.org](mailto:referee@ayso13.org)
- Phone: 626-316-6900
- Game-day emergencies: 626-702-AYSO

---

## Related Pages

- [Refereeing Overview](/referees) — Getting started
- [Laws of the Game](/referees/laws) — Official rules
- [Referee Scheduling](/referees/scheduling) — Game assignments

---

*Last updated: [DATE]*
