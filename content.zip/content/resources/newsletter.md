# Newsletter

Stay informed about Region 13 news, events, and announcements.

---

## Subscribe

Sign up to receive the Region 13 newsletter.

[INLEAGUE: Newsletter subscription link]

---

## What is Included

The newsletter includes:
- Season updates and reminders
- Event announcements
- Field status notifications
- Registration deadlines
- Volunteer opportunities
- Community news

---

## Additional Publications

**AYSO WhistleStop Newsletter**
National AYSO referee newsletter.

[INLEAGUE: WhistleStop subscription link]

---

## Contact

- Newsletter questions: [info@ayso13.org](mailto:info@ayso13.org)
- Communication Director: [webmaster@ayso13.org](mailto:webmaster@ayso13.org)

---

## Related Pages

- [Contact](/contact) — All contact information
- [Resources](/resources) — All resources

---

*Last updated: [DATE]*
