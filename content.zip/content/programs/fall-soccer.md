# Fall Soccer

Fall Soccer is our core recreational program for players ages 6-14. The season runs from September through mid-November.

[IMAGE: Fall soccer game action shot]

---

## Quick Facts

- Season: September (after Labor Day) through mid-November
- Ages: 6U through 14U
- Games: Saturdays
- Practices: One weeknight per week
- Cost: $210-$240 depending on registration date

---

## Divisions

| Division | Ages | Format | Game Duration |
|----------|------|--------|---------------|
| 6U | 6 | 4v4, no goalkeepers | 40 min |
| 8U | 7-8 | 4v4, no goalkeepers | 40 min |
| 10U | 9-10 | 7v7 with goalkeepers | 50 min |
| 12U | 11-12 | 9v9 | 60 min |
| 14U | 13-14 | 11v11 (full field) | 70 min |

Age is determined as of July 31. See [age chart](/register/age-divisions) for exact birth date cutoffs.

---

## Schedule

### Practices
- 6U-8U: Once per week, typically 5-6pm
- 10U-12U: Once per week, typically 6-7:30pm
- 14U: Once per week, typically 7-8:30pm

Practice day and time are set by your coach based on field availability.

### Games
- All divisions play on Saturdays
- Game times vary by division and field availability
- Season includes 8-10 games

### Season Timeline
- Registration opens: May 1
- Team rosters announced: Early August
- Practices begin: Day after Labor Day
- Games begin: Saturday after Labor Day
- Regular season ends: Pre-Thanksgiving
- Playoffs (10U-14U): One to two weeks after Thanksgiving

---

## How It Works

### 6U-8U ("Friendly" Divisions)
- Focus on learning and fun
- No standings or score emphasis
- Teams organized by school or neighborhood when possible

### 10U-14U (Competitive Divisions)
- Balanced teams created through blind draw
- Standings tracked throughout season
- Single-elimination playoffs after regular season
- Division champions determined

---

## Registration

### Fees (2025)

| Registration Period | Cost |
|---------------------|------|
| May 1 - May 31 | $210 |
| Before July 1 | $225 |
| After July 1 | $240 |

Sibling discount: $20 off additional children (May only)

### What's Included
- Team jersey, shorts, and socks
- Weekly practices
- Saturday games
- End-of-season award
- Insurance coverage

### Scholarships
Financial assistance is available. Contact [registrar@ayso13.org](mailto:registrar@ayso13.org) — all requests are confidential.

### Refund Policy
- Through July 15: All but $40 refundable
- Through Labor Day: All but $60 refundable
- After Labor Day: Non-refundable

[INLEAGUE: Registration link]

---

## Volunteer Requirements

Each team needs:
- Head Coach
- Assistant Coach
- Two Referees
- Team Manager

Coaches and referees attend training classes (typically 4 hours). See [training classes](/volunteers/classes) for the schedule.

---

## Related Pages

- [Getting Started](/parents/getting-started) — Overview for new families
- [Equipment Guide](/parents/equipment) — What to buy
- [Age Divisions](/register/age-divisions) — Birth date cutoffs
- [Volunteer Training](/volunteers/classes) — Coach and referee certification
- [NEXT](/programs/next) — Advanced training supplement

---

*Last updated: [DATE]*
