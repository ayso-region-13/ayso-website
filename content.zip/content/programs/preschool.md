# Preschool Soccer (4U/5U)

The Preschool program introduces children ages 4-5 to soccer through play and motor skill development.

[IMAGE: Young children playing with soccer balls]

---

## Quick Facts

- Ages: 4U (age 4) and 5U (age 5)
- When: Saturday mornings, one hour per week
- Season: Early September through mid-October (8 weeks)
- Format: Jamboree style — no formal teams or games

---

## How It Works

This is not traditional soccer. Sessions focus on helping children develop basic motor skills — hopping, skipping, jumping, running, throwing, balancing, and kicking — through play-based activities.

Children are grouped by age (4U or 5U) and meet once per week for one hour. There are no formal teams, no scores, and no standings.

### Session Times
Sessions typically run at:
- 8-9am
- 9-10am
- 10-11am

You'll be assigned to a session when you register.

---

## Schedule (Fall 2025)

- Season: September 6 through October 18
- Makeup dates: October 25 and November 8 (if needed for rain)
- Location: Announced before season starts

---

## Registration

Players are randomly assigned to a team and session. You can request a session change up to two weeks before the season starts.

Team assignments are published in August.

[INLEAGUE: Registration link]

---

## What to Bring

- Size 3 soccer ball
- Shin guards (required)
- Water bottle
- Comfortable clothes and shoes (cleats optional)

Uniforms are provided by the region.

---

## Contact

For questions about the Preschool program: [4u5u@ayso13.org](mailto:4u5u@ayso13.org)

---

## Related Pages

- [Programs Overview](/programs) — All Region 13 programs
- [Equipment Guide](/parents/equipment) — What to buy
- [Getting Started](/parents/getting-started) — Overview for new families

---

*Last updated: [DATE]*
