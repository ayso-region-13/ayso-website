# Training Classes

Volunteer training is available through eTrainU, with in-person classes scheduled before each season.

---

## Required Online Training (All Volunteers)

These one-time courses are completed through eTrainU:

- LiveScan background screening
- SafeSport (annual renewal required)
- Safe Haven
- CDC Concussion Awareness
- Sudden Cardiac Arrest Awareness

[INLEAGUE: eTrainU link]

---

## Coach Training

Coaches complete age-specific certification courses:

| Division | Course |
|----------|--------|
| 4U/5U | No training required (professional coaches hired) |
| 6U | 6U Coach Certification |
| 8U | 8U Coach Certification |
| 10U | 10U Coach Certification |
| 12U | 12U Coach Certification |
| 14U | Intermediate Certification (requires 12U coaching experience) |
| 16U/19U | Advanced Certification |

Courses are available online, in-person, or as a hybrid. In-person classes are scheduled in August before the fall season.

Recommended: "Keep Girls In Sport" course

See [Coach Training](/coaches/training) for details.

---

## Referee Training

Referees complete certification courses based on the divisions they will officiate:

| Course | Covers |
|--------|--------|
| 8U Official | 6U, 7U, 8U games |
| Regional Referee | 10U and above |
| Intermediate Referee | 12U (field experience required) |
| Intermediate Observation | Before 14U officiating |

Courses are available online, in-person, or as a hybrid. Multiple classes are scheduled in July and August at the Altadena clubhouse or in South Pasadena.

See [Referee Training](/referees/training) for details.

---

## Team Manager Training

Team managers complete:
- Orientation video and presentation
- Background check
- Safe Haven training (20 minutes online)

See [Manager Training](/managers/training) for details.

---

## LiveScan Fingerprinting

LiveScan is a one-time requirement for all adult volunteers. Complete this at:

Only Stop Travel
Woodbury Road, Altadena

You only need to repeat LiveScan if you move to a new region.

---

## Training Schedule

In-person classes are scheduled nearly every weekend in August, with weeknight options available. The full schedule is posted in July.

[INLEAGUE: Training calendar link]

---

## Contact

- Training questions: [info@ayso13.org](mailto:info@ayso13.org)
- Phone: 626-316-6900

---

## Related Pages

- [Volunteering Overview](/volunteers) — Getting started
- [Coach Training](/coaches/training) — Coaching certification
- [Referee Training](/referees/training) — Referee certification

---

*Last updated: [DATE]*
