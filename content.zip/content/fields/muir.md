# Muir High School

Muir High School has multiple field areas for practices.

---

## Location

Near 711 W. Woodbury Rd., Altadena

[INLEAGUE: Google Maps link]

---

## Field Areas

- Muir North: Practice fields with portable lighting
- Muir Central: Large turf field (check current availability)
- Muir South: Softball field (see [Muir South](/fields/muir-south))

---

## Parking

Exercise caution on Montana Street's west end. There are subtle "No Parking" signs near the school bus lot, and local enforcement actively tickets this zone, including on Sunday evenings.

---

## Portable Lighting (Muir North)

Nine mobile, gas-powered light units serve the practice areas. These are maintained by Region 13 and must be powered down when not in use.

### Startup Procedure
1. Open hood (code: 5013)
2. Start engine with all switches off
3. Warm engine briefly
4. Activate generator and light switches sequentially

### Shutdown Procedure
1. Reverse the startup sequence
2. Ensure ignition reaches full "OFF" position to prevent battery drain

If your practice ends at 9:00 PM, shut down all portable lights before leaving the field.

### Light Maintenance
Report equipment problems to Marco: 818-468-3693

---

## Contact

- Field issues: [fields@ayso13.org](mailto:fields@ayso13.org)
- Light maintenance: Marco at 818-468-3693
- Game-day emergencies: 626-702-AYSO

---

## Related Pages

- [Field Locations](/fields) — All fields
- [Muir South](/fields/muir-south) — Softball field

---

*Last updated: [DATE]*
